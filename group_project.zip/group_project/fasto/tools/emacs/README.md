# Emacs mode for Fasto

This Emacs mode provides:

  + syntax highlighting, and
  + automatic indentation
  
for Fasto programs.  See the file itself for installation instructions.
